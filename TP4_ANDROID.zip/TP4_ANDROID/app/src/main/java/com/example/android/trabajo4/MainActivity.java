package com.example.android.trabajo4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public User user1, user2, user3;
    public int mayor = 0;
    public int menor = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         user1 = new User("Kevin", "Liao", 1);
         user2 = new User("Dan", "Farach", 2);
         user3 = new User("Leonel", "Sujatovich", 3);

         ArrayList<User> lista = new ArrayList<User>();

         lista.add(user1);
         lista.add(user2);
         lista.add(user3);

         for (User u:  lista) {
             Log.i("Text", u.getName());
             Log.i("Text", u.getSurname());
             Log.i("Text", String.valueOf(u.getId()));
         }

        for (User u:  lista) {
             if (u.getId()> mayor){
                 mayor = u.getId();
             }
             if (u.getId() < menor) {
                 menor = u.getId();
             }

        }
        Log.i("Mayor", String.valueOf(mayor));
        Log.i("Menor", String.valueOf(menor));
    }
}
