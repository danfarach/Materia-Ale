package com.example.android.myapplication;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {

    private Button rojo, verde, mas, menos;
    private TextView texto;
    private float tamanio = 24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (tamanio < 1) {
            tamanio = 1;
        }


        texto = findViewById(R.id.textView);
        rojo = findViewById(R.id.rojo);
        verde = findViewById(R.id.verde);
        mas = findViewById(R.id.masTamano);
        menos = findViewById(R.id.menosTamano);



        rojo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto.setTextColor(Color.RED);
            }
        });

        verde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto.setTextColor(Color.GREEN);
            }
        });

        mas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tamanio ++;
                texto.setTextSize(tamanio);

            }
        });

        menos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tamanio --;
                texto.setTextSize(tamanio);
            }
        });


    }
}
