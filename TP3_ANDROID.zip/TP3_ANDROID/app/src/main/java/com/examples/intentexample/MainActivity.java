package com.examples.intentexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    public EditText editName; //Declaro los EditText y los nombro
    public EditText editCont;
    public Button btnOk;

    public String textoIngresado;

    public String dan = "Dan";
    public String cdan = "Farach";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.edt_name); //Relaciono a los EditText declarados con el ID de xml
        editCont = findViewById(R.id.edt_contraseña);
        btnOk = findViewById(R.id.btn_ok);

        btnOk.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                if (editName.getText().toString().equals(dan) && editCont.getText().toString().equals(cdan)) {

                    textoIngresado = editName.getText().toString();
                    editName.setText(""); //Seteo el espacio del nombre en blanco
                    editCont.setText (""); //Lo mismo con la contraseña
                    Intent intentMain2 = new Intent(getApplicationContext(), Main2Activity.class);

                    intentMain2.putExtra("TEXTOINGRESADO", "Bienvenido, " + textoIngresado);

                    startActivity(intentMain2); //Inicio la otra Activity
                }

                else {
                    Toast.makeText(getApplicationContext(),"Usuario o contraseña incorrecto " + "", Toast.LENGTH_SHORT).show(); /*
                    Un toast es un texto que aparece y desaparece */
                    editName.setText("");
                    editCont.setText("");
                }


            }
        });

    }
}
