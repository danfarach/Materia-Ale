package com.example.android.cambiodeidentidad;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public TextView nombre, apellido, dni;
    public Button boton1, boton2, boton3, boton4;

    public Usuario usuario1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario1 = new Usuario("Nombre", "Apellido", "DNI");

        nombre = findViewById(R.id.nombre);
        apellido = findViewById(R.id.apellido);
        dni = findViewById(R.id.dni);
        boton1 = findViewById(R.id.user1);
        boton2 = findViewById(R.id.user2);
        boton3 = findViewById(R.id.user3);
        boton4 = findViewById(R.id.user4);


        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setTextSize(20);
                apellido.setTextSize(20);
                dni.setTextSize(20);
                usuario1.setNombre("Kevin");
                usuario1.setApellido("Liao");
                usuario1.setDNI("12345678");

                nombre.setText(usuario1.getNombre());
                apellido.setText(usuario1.getApellido());
                dni.setText(usuario1.getDNI());
            }

        });
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setTextSize(20);
                apellido.setTextSize(20);
                dni.setTextSize(20);
                usuario1.setNombre("Dan");
                usuario1.setApellido("Farach");
                usuario1.setDNI("87654321");

                nombre.setText(usuario1.getNombre());
                apellido.setText(usuario1.getApellido());
                dni.setText(usuario1.getDNI());
            }

        });

        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setTextSize(20);
                apellido.setTextSize(20);
                dni.setTextSize(20);
                usuario1.setNombre("Manu");
                usuario1.setApellido("Bossio");
                usuario1.setDNI("44444444");

                nombre.setText(usuario1.getNombre());
                apellido.setText(usuario1.getApellido());
                dni.setText(usuario1.getDNI());
            }

        });
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setTextSize(20);
                apellido.setTextSize(20);
                dni.setTextSize(20);
                usuario1.setNombre("Dan");
                usuario1.setApellido("Szujatovich");
                usuario1.setDNI("0");

                nombre.setText(usuario1.getNombre());
                apellido.setText(usuario1.getApellido());
                dni.setText(usuario1.getDNI());
            }

        });


    }
}
