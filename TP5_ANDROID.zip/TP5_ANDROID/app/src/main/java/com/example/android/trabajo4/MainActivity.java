package com.example.android.trabajo4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public User user1, user2, user3;
    public long mayor = 0;
    public long menor = 1000000000;
    public User u;
    public ArrayList<User> lista;

    public Button boton ;
    public EditText e1, e2, e3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         user1 = new User("Kevin", "Liao", "13433");
         user2 = new User("Dan", "Farach", "243513132");
         user3 = new User("Leonel", "Sujatovich", "131243533");

         lista = new ArrayList<User>();

         lista.add(user1);
         lista.add(user2);
         lista.add(user3);

         for (User u:  lista) {
             Log.i("Text", u.getName());
             Log.i("Text", u.getSurname());
             Log.i("Text", String.valueOf(u.getId()));
         }

       /* for (User u:  lista) {
             if (u.getId()> mayor){
                 mayor = u.getId();
             }
             if (u.getId() < menor) {
                 menor = u.getId();
             }

        }*/

        Log.i("Mayor", String.valueOf(mayor));
        Log.i("Menor", String.valueOf(menor));

        boton = findViewById(R.id.button);
        e1 = findViewById(R.id.nombre);
        e2 = findViewById(R.id.apellido);
        e3 = findViewById(R.id.id);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = String.valueOf(e1.getText());
                String b = String.valueOf(e2.getText());
                String c = String.valueOf(e3.getText());

                User u = new User(a, b, c);

                lista.add(u);

                e1.setText("");
                e2.setText("");
                e3.setText("");

                for (User k: lista) {
                    Log.i("Text", k.getName());
                    Log.i("Text", k.getSurname());
                    Log.i("Text", String.valueOf(k.getId()));
                }

            }
        });
    }
}
