package com.example.android.trabajo4;

import android.app.Activity;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public User user1, user2, user3;
    public long mayor = 0;
    public long menor = 1000000000;
    public User u;
    public ArrayList<User> lista;
    public TextView titulo;

    public Button boton, boton2 ;
    public EditText e1, e2, e3;

    private int p;

    private ListView listViewUsuarios;
    private AdapterProductos adapterUsuarios;

    private Toolbar toolbar;

    private boolean eliminando = false, editando = false;

    private FloatingActionButton fab;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewUsuarios = findViewById(R.id.lv);

        fab = findViewById(R.id.action_show);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                e3.setVisibility(View.VISIBLE);
                e1.setVisibility(View.VISIBLE);
                e2.setVisibility(View.VISIBLE);

                e1.setText("");
                e2.setText("");
                e3.setText("");
                boton.setVisibility(View.VISIBLE);
                listViewUsuarios.setVisibility(View.INVISIBLE);

            }
        });

        titulo = findViewById(R.id.textView3);

        boton2 = findViewById(R.id.btn_acceptar);

        lista = new ArrayList<User>();

        user1 = new User("Kevin", "Liao", "13433");
        user2 = new User("Dan", "Farach", "243513132");
        user3 = new User("Leonel", "Sujatovich", "131243533");
        lista.add(user1);
        lista.add(user2);
        lista.add(user3);

        adapterUsuarios = new AdapterProductos(this, lista);
        listViewUsuarios.setAdapter(adapterUsuarios);

        for (User u:  lista) {
             Log.i("Text", u.getName());
             Log.i("Text", u.getSurname());
             Log.i("Text", String.valueOf(u.getId()));
         }


        Log.i("Mayor", String.valueOf(mayor));
        Log.i("Menor", String.valueOf(menor));

        boton = findViewById(R.id.button);
        e1 = findViewById(R.id.nombre);
        e2 = findViewById(R.id.apellido);
        e3 = findViewById(R.id.id);
        toolbar =  findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        e3.setVisibility(View.INVISIBLE);
        e1.setVisibility(View.INVISIBLE);
        e2.setVisibility(View.INVISIBLE);
        boton.setVisibility(View.INVISIBLE);
        boton2.setVisibility(View.INVISIBLE);

        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                lista.get(p).setName(e1.getText().toString());
                lista.get(p).setId(e3.getText().toString());
                lista.get(p).setSurname(e2.getText().toString());

                for (User k: lista) {
                    Log.i("Text", k.getName());
                    Log.i("Text", k.getSurname());
                    Log.i("Text", String.valueOf(k.getId()));

                }

                listViewUsuarios.setAdapter(adapterUsuarios);


                boton2.setVisibility(View.INVISIBLE);
                e3.setVisibility(View.INVISIBLE);
                e1.setVisibility(View.INVISIBLE);
                e2.setVisibility(View.INVISIBLE);
                listViewUsuarios.setVisibility(View.VISIBLE);
            }
        });

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = String.valueOf(e1.getText());
                String b = String.valueOf(e2.getText());
                String c = String.valueOf(e3.getText());

                if (!a.equals("") && !b.equals("") && !c.equals("")) {
                    User u = new User(a, b, c);

                    lista.add(u);

                    e1.setText("");
                    e2.setText("");
                    e3.setText("");

                    for (User k: lista) {
                        Log.i("Text", k.getName());
                        Log.i("Text", k.getSurname());
                        Log.i("Text", String.valueOf(k.getId()));

                    }
                    listViewUsuarios.setAdapter(adapterUsuarios);

                    e3.setVisibility(View.INVISIBLE);
                    e1.setVisibility(View.INVISIBLE);
                    e2.setVisibility(View.INVISIBLE);
                    boton.setVisibility(View.INVISIBLE);
                    listViewUsuarios.setVisibility(View.VISIBLE);
                }

                else {
                    e3.setVisibility(View.INVISIBLE);
                    e1.setVisibility(View.INVISIBLE);
                    e2.setVisibility(View.INVISIBLE);
                    boton.setVisibility(View.INVISIBLE);
                    listViewUsuarios.setVisibility(View.VISIBLE);
                }



            }
        });


        listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Apellido: " + lista.get(position).getSurname() + " DNI: " + lista.get(position).getId() , Toast.LENGTH_SHORT).show();
            }
        });
    }


    class AdapterProductos extends ArrayAdapter<User>
    {

        private Activity context;
        private ArrayList<User> listProductos;

        class ViewHolder
        {
            TextView txtNombre;
            TextView txtCantidad;

        }

        AdapterProductos(Activity context, ArrayList<User> listProductos)
        {
            super(context, R.layout.item_producto, listProductos);
            this.context = context;
            this.listProductos = listProductos;
        }

        public View getView(int position, View convertView, ViewGroup parent)
        {
            View item = convertView;
            ViewHolder holder;

            if(item == null)
            {
                LayoutInflater inflater = context.getLayoutInflater();
                item = inflater.inflate(R.layout.item_producto, null);

                holder = new ViewHolder();
                holder.txtNombre = item.findViewById(R.id.textView);
                item.setTag(holder);
            }
            else
            {
                holder = (ViewHolder)item.getTag();
            }

            holder.txtNombre.setText("Nombre: " + listProductos.get(position).getName());
            //holder.txtCantidad.setText(listProductos.get(position).getSurname());
            return(item);
        }
    }



    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {

        switch (item.getItemId())
        {

            case R.id.action_delete:

                Toast.makeText(MainActivity.this, "Seleccione al sujeto que quiere matar", Toast.LENGTH_SHORT).show();

                eliminando = true;

                Log.i("Eliminando", String.valueOf(eliminando));

                listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        if (eliminando == true) {
                            eliminando = false;
                            Log.i("Eliminando", String.valueOf(eliminando));
                            lista.remove(position);
                            listViewUsuarios.setAdapter(adapterUsuarios);
                        }
                        else {
                            listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Toast.makeText(MainActivity.this, "Apellido: " + lista.get(position).getSurname() + " DNI: " + lista.get(position).getId() , Toast.LENGTH_SHORT).show();
                                }
                            });
                        }

                    }
                });
                break;


            case R.id.action_edit:

                Toast.makeText(MainActivity.this, "Seleccione el sujeto que quiere editar", Toast.LENGTH_SHORT).show();

                editando = true;

                listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        if (editando == true) {
                            editando = false;

                            p = position;

                            e3.setVisibility(View.VISIBLE);
                            e1.setVisibility(View.VISIBLE);
                            e2.setVisibility(View.VISIBLE);
                            listViewUsuarios.setVisibility(View.INVISIBLE);

                            boton2.setVisibility(View.VISIBLE);

                            e1.setText(lista.get(position).getName());
                            e2.setText(lista.get(position).getSurname());
                            e3.setText(lista.get(position).getId());


                        }
                        else {
                            listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Toast.makeText(MainActivity.this, "Apellido: " + lista.get(position).getSurname() + " DNI: " + lista.get(position).getId() , Toast.LENGTH_SHORT).show();
                                }
                            });
                        }

                    }
                });


                break;

        }

        return true;
    }

}
