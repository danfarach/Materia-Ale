package com.example.android.trabajo4;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public User user1, user2, user3;
    public long mayor = 0;
    public long menor = 1000000000;
    public User u;
    public ArrayList<User> lista;

    public Button boton ;
    public EditText e1, e2, e3;

    private ListView listViewUsuarios;
    private AdapterProductos adapterUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewUsuarios = findViewById(R.id.lv);

        lista = new ArrayList<User>();

        user1 = new User("Kevin", "Liao", "13433");
        user2 = new User("Dan", "Farach", "243513132");
        user3 = new User("Leonel", "Sujatovich", "131243533");
        lista.add(user1);
        lista.add(user2);
        lista.add(user3);

        adapterUsuarios = new AdapterProductos(this, lista);
        listViewUsuarios.setAdapter(adapterUsuarios);



         for (User u:  lista) {
             Log.i("Text", u.getName());
             Log.i("Text", u.getSurname());
             Log.i("Text", String.valueOf(u.getId()));
         }

       /* for (User u:  lista) {
             if (u.getId()> mayor){
                 mayor = u.getId();
             }
             if (u.getId() < menor) {
                 menor = u.getId();
             }

        }*/

        Log.i("Mayor", String.valueOf(mayor));
        Log.i("Menor", String.valueOf(menor));

        boton = findViewById(R.id.button);
        e1 = findViewById(R.id.nombre);
        e2 = findViewById(R.id.apellido);
        e3 = findViewById(R.id.id);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = String.valueOf(e1.getText());
                String b = String.valueOf(e2.getText());
                String c = String.valueOf(e3.getText());


                User u = new User(a, b, c);

                lista.add(u);

                e1.setText("");
                e2.setText("");
                e3.setText("");

                for (User k: lista) {
                    Log.i("Text", k.getName());
                    Log.i("Text", k.getSurname());
                    Log.i("Text", String.valueOf(k.getId()));

                }
                listViewUsuarios.setAdapter(adapterUsuarios);

            }
        });


        listViewUsuarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, lista.get(position).getName() + " desaprobó", Toast.LENGTH_SHORT).show();
            }
        });
    }

    class AdapterProductos extends ArrayAdapter<User>
    {

        private Activity context;
        private ArrayList<User> listProductos;

        class ViewHolder
        {
            TextView txtNombre;
            TextView txtCantidad;
            TextView txtPrecio;

        }

        AdapterProductos(Activity context, ArrayList<User> listProductos)
        {
            super(context, R.layout.item_producto, listProductos);
            this.context = context;
            this.listProductos = listProductos;
        }

        public View getView(int position, View convertView, ViewGroup parent)
        {
            View item = convertView;
            ViewHolder holder;

            if(item == null)
            {
                LayoutInflater inflater = context.getLayoutInflater();
                item = inflater.inflate(R.layout.item_producto, null);

                holder = new ViewHolder();
                holder.txtNombre = item.findViewById(R.id.textView);
                holder.txtCantidad = item.findViewById(R.id.textView2);
                holder.txtPrecio = item.findViewById(R.id.textView3);
                item.setTag(holder);
            }
            else
            {
                holder = (ViewHolder)item.getTag();
            }

            holder.txtNombre.setText(listProductos.get(position).getName());
            holder.txtCantidad.setText(listProductos.get(position).getSurname());
            holder.txtPrecio.setText(String.valueOf(listProductos.get(position).getId()));
            return(item);
        }
    }



}
